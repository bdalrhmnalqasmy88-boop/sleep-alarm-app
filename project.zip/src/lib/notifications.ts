import type { SleepSession } from './storage';

type AlarmConfig = {
  id: number;
  title: string;
  body: string;
  at: Date;
  sound: string;
  volume: number;
};

const isCapacitor = typeof (window as any).Capacitor !== 'undefined';

async function getLocalNotifications() {
  if (!isCapacitor) return null;
  try {
    const mod = await import('@capacitor/local-notifications');
    return mod.LocalNotifications;
  } catch {
    return null;
  }
}

export async function initializeNotifications(): Promise<void> {
  const LocalNotifications = await getLocalNotifications();
  if (!LocalNotifications) return;
  try {
    await LocalNotifications.createChannel({
      id: 'alarm-channel',
      name: 'Sleep alarms',
      description: 'Sleep Cycle Alarm notifications',
      importance: 5,
      sound: undefined,
      vibration: true,
    });
  } catch {
    // channel may already exist
  }
}

export async function scheduleAlarm(config: AlarmConfig): Promise<void> {
  const LocalNotifications = await getLocalNotifications();
  if (!LocalNotifications) return;

  try {
    await LocalNotifications.requestPermissions();
  } catch {
    // permissions may already be granted
  }

  try {
    await LocalNotifications.schedule({
      notifications: [
        {
          id: config.id,
          title: config.title,
          body: config.body,
          schedule: { at: config.at },
          sound: undefined,
          smallIcon: 'ic_stat_icon',
          largeIcon: 'ic_launcher',
          channelId: 'alarm-channel',
          ongoing: true,
        },
      ],
    });
  } catch {
    // notification scheduling failed — app still works in foreground
  }
}

export async function cancelAlarm(id: number): Promise<void> {
  const LocalNotifications = await getLocalNotifications();
  if (!LocalNotifications) return;
  try {
    await LocalNotifications.cancel({ notifications: [{ id }] });
  } catch {
    // ignore
  }
}

export async function cancelAllAlarms(): Promise<void> {
  const LocalNotifications = await getLocalNotifications();
  if (!LocalNotifications) return;
  try {
    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel({
        notifications: pending.notifications.map((n) => ({ id: n.id })),
      });
    }
  } catch {
    // ignore
  }
}

export function makeSessionFromAlarm(
  wakeTime: string,
  bedtime: Date,
  wakeDate: Date,
  cycles: number,
  durationMin: number,
): SleepSession {
  return {
    id: Date.now().toString(36) + Math.random().toString(36).substring(2, 7),
    wake_time: wakeTime,
    bedtime: bedtime.toISOString(),
    final_wake: wakeDate.toISOString(),
    cycles,
    duration_min: durationMin,
    completed: false,
    created_at: new Date().toISOString(),
  };
}
