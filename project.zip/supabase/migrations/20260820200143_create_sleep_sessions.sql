/*
# Create sleep_sessions table (single-tenant, no auth)

1. New Tables
- `sleep_sessions`
  - `id` (uuid, primary key)
  - `wake_time` (time, not null) — the user's target final wake-up time (HH:MM)
  - `bedtime` (timestamptz, not null) — when the first alarm fired and sleep started
  - `final_wake` (timestamptz, not null) — the scheduled final alarm time
  - `cycles` (int, not null) — number of 90-min sleep cycles planned
  - `duration_min` (int, not null) — planned sleep duration in minutes
  - `completed` (boolean, default false) — whether the final alarm was dismissed
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `sleep_sessions`.
- Single-tenant app with no sign-in: allow anon + authenticated full CRUD because the
  data is intentionally shared/public on this device.
*/

CREATE TABLE IF NOT EXISTS sleep_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wake_time time NOT NULL,
  bedtime timestamptz NOT NULL,
  final_wake timestamptz NOT NULL,
  cycles int NOT NULL,
  duration_min int NOT NULL,
  completed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sleep_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sleep_sessions" ON sleep_sessions;
CREATE POLICY "anon_select_sleep_sessions" ON sleep_sessions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sleep_sessions" ON sleep_sessions;
CREATE POLICY "anon_insert_sleep_sessions" ON sleep_sessions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sleep_sessions" ON sleep_sessions;
CREATE POLICY "anon_update_sleep_sessions" ON sleep_sessions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sleep_sessions" ON sleep_sessions;
CREATE POLICY "anon_delete_sleep_sessions" ON sleep_sessions FOR DELETE
  TO anon, authenticated USING (true);
